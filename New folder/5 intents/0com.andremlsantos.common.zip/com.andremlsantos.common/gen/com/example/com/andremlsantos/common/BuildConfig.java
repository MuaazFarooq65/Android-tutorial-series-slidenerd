/** Automatically generated file. DO NOT MODIFY */
package com.example.com.andremlsantos.common;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}