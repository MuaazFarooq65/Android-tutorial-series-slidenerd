package com.example.com.andremlsantos.common;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class AlarmActivity extends Activity {
	String message;
	List<Integer> hours, minutes;
	Spinner hoursSpinner, minutesSpinner;
	EditText editText;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alarm);
		fillTimers();
	}

	private void fillTimers() {
		hoursSpinner = (Spinner) findViewById(R.id.spinner1);
		hours = new ArrayList<Integer>();
		for (int i = 0; i < 24; i++) {
			hours.add(i + 1);
		}
		ArrayAdapter<Integer> dataHour = new ArrayAdapter<Integer>(this,
				android.R.layout.simple_spinner_item, hours);
		dataHour.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		hoursSpinner.setAdapter(dataHour);

		minutesSpinner = (Spinner) findViewById(R.id.spinner2);
		minutes = new ArrayList<Integer>();
		for (int i = 0; i < 60; i++) {
			minutes.add(i + 1);
		}
		ArrayAdapter<Integer> dataMin = new ArrayAdapter<Integer>(this,
				android.R.layout.simple_spinner_item, minutes);
		dataMin.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		minutesSpinner.setAdapter(dataMin);
	}

	public void createAlarm(View view) {
		Integer hour = (Integer) hoursSpinner.getSelectedItem();
		Integer minutes = (Integer) minutesSpinner.getSelectedItem();
		editText = (EditText) findViewById(R.id.editText1);
		message = editText.getText().toString();

		Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
				.putExtra(AlarmClock.EXTRA_MESSAGE, message)
				.putExtra(AlarmClock.EXTRA_HOUR, hour)
				.putExtra(AlarmClock.EXTRA_MINUTES, minutes);
		if (intent.resolveActivity(getPackageManager()) != null) {
			startActivity(intent);
		}
	}

}
