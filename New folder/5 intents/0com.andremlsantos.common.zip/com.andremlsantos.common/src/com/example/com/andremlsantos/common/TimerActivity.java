package com.example.com.andremlsantos.common;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.EditText;

public class TimerActivity extends Activity {
	EditText inputMessage, inputTimer;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_timer);
	}

	public void startTimer(View view) {
		inputMessage = (EditText) findViewById(R.id.editText2);
		String message = inputMessage.getText().toString();
		
		inputTimer = (EditText) findViewById(R.id.editText1);
		Integer seconds = Integer.valueOf(inputTimer.getText().toString());
		
		Intent intent = new Intent(AlarmClock.ACTION_SET_TIMER)
				.putExtra(AlarmClock.EXTRA_MESSAGE, message)
				.putExtra(AlarmClock.EXTRA_LENGTH, seconds)
				.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
		if (intent.resolveActivity(getPackageManager()) != null) {
			startActivity(intent);
		}
	}
}