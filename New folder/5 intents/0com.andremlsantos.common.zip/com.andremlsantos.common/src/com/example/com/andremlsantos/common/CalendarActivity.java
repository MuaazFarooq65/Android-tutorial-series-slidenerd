package com.example.com.andremlsantos.common;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Events;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

public class CalendarActivity extends Activity implements
		android.view.View.OnClickListener {

	private Button button;
	private Calendar calendarBegin;
	private int day;
	private int month;
	private int year;

	private static final int DATE_PICKER_ID = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calendar);

		button = (Button) findViewById(R.id.calendarButton);
		calendarBegin = Calendar.getInstance();
		day = calendarBegin.get(Calendar.DAY_OF_MONTH);
		month = calendarBegin.get(Calendar.MONTH);
		year = calendarBegin.get(Calendar.YEAR);
		button.setOnClickListener(this);
	}

	@Override
	@Deprecated
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_PICKER_ID:
			return new DatePickerDialog(this, datePickerListener, year, month,
					day);
		}
		return null;
	}

	private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {

		// while dialog box is closed, below method is called.
		public void onDateSet(DatePicker view, int selectedYear,
				int selectedMonth, int selectedDay) {
			year = selectedYear;
			month = selectedMonth;
			day = selectedDay;

			// Set the Date String in Button
			button.setText(day + " / " + (month + 1) + " / " + year);
		}
	};

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		showDialog(DATE_PICKER_ID);
	}

	public void creatEvent(View view) {
		EditText inputTitle = (EditText) findViewById(R.id.eventTitle);
		EditText inputLocation = (EditText) findViewById(R.id.eventLocation);

		String title = inputTitle.getText().toString();
		String location = inputLocation.getText().toString();

		Intent intent = new Intent(Intent.ACTION_INSERT)
				.setData(Events.CONTENT_URI).putExtra(Events.TITLE, title)
				.putExtra(Events.EVENT_LOCATION, location)
				.putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, calendarBegin);
		if (intent.resolveActivity(getPackageManager()) != null) {
			startActivity(intent);
		}
	}

}
