package com.example.baseadapter;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ActionBar;
import android.app.ActivityManager;
import android.app.Fragment;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity implements OnClickListener {
	/*
	 * 1 store all data somewhere [titles, description,and images]
	 * 2 define the structure of a single row of your listview inside single_row.xml
	 * 3 define the listview inside main layout and reference it in your actvity
	 * 4 create your custom adapter that puts the data for each row inside getView method
	 */
	
	Button calcular;
	EditText text;
	ListView list;
	List<Integer> boxPositions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //findviewbyid retorn view object por isso fazemos typecast
        list = (ListView) findViewById(R.id.listView1);
        VivzAdapter adapter = new VivzAdapter(this);
        list.setAdapter(adapter);
        
        text = (EditText) findViewById(R.id.editText1);
        calcular = (Button) findViewById(R.id.button1);
        calcular.setOnClickListener(this);
        boxPositions = adapter.boxPositions;
        
        Runtime rt = Runtime.getRuntime();
        long maxMemory = rt.maxMemory();
        Log.v("VIVZ", "maxMemory:" + Long.toString(maxMemory/1000000));
        
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int memoryClass = am.getMemoryClass();
        Log.v("VIVZ", "memoryClass:" + Integer.toString(memoryClass));
    }
    
	@Override
	public void onClick(View v) {
		int result=0;
		for (int i = 0; i < boxPositions.size(); i++) {
			result+=boxPositions.get(i);
		}
		text.setText(""+result);
	}
}

class SingleRow {
	String title, descripton;
	int image;
	
	public SingleRow(String title, String descripton, int image) {
		this.image = image;
		this.descripton = descripton;
		this.title = title;
	}
}

/*
 * 1 create class extends BaseAdapter and implement all the methods
 * 2 Maintain some array inside your BaseAdapter class that will contain all the data [titles+description+images]
 * 3 use getView method to fill the data from your array inside the custom structure of that single row each row 
 */
class VivzAdapter extends BaseAdapter implements OnCheckedChangeListener{
	ArrayList<SingleRow> list;
	List<Integer> boxPositions = new ArrayList<Integer>();
	Context context;
	
	VivzAdapter(Context c){
		context=c;
		list = new ArrayList<SingleRow>();
		//temos meter dados dentro arrayList
		Resources res = c.getResources();
		 
		String[] titles =  res.getStringArray(R.array.titles);
		String[] descriptions = res.getStringArray(R.array.descriptions);
		int[] images = {R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4, R.drawable.image5,R.drawable.image6, R.drawable.image7, R.drawable.image8, R.drawable.image9, R.drawable.image10, R.drawable.image11, R.drawable.image12, R.drawable.image13, R.drawable.image14,R.drawable.image15, R.drawable.image16, R.drawable.image17, R.drawable.image18, R.drawable.image19, R.drawable.image20, R.drawable.image21,R.drawable.image22, R.drawable.image23, R.drawable.image24,R.drawable.image25, R.drawable.image26,R.drawable.image27,R.drawable.image28,R.drawable.image29,R.drawable.image30};
		for (int i = 0; i < 30; i++) {
			list.add(new SingleRow(titles[i], descriptions[i], images[i]));
		}
	}
	
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	class MyViewHolder {
		TextView title;
		TextView description;
		ImageView image;
		CheckBox box;
		
		MyViewHolder(View view){
			title = (TextView) view.findViewById(R.id.textView1);
			description = (TextView) view.findViewById(R.id.textView2);
			image =  (ImageView) view.findViewById(R.id.imageView1);	
			box = (CheckBox) view.findViewById(R.id.checkBox1);
		}
	}
	
	
	/*
	 * 1 get root view = RelativeLayout
	 * 2 use root view to find other views
	 * 3 set the values
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		MyViewHolder holder = null;
		/*
		 * nao podemos usar findViewById pq getView � chamado para cada row e como cada linha � diferente dependemos de um novo getView object para cada linha
		 * para usarmos LayoutInflater precisamos referencia ao context object!
		 * SE PRECISARMOS DO MESMO OBJECTO SEMPRE USAMOS findViewById
		 * SE PRECISARMOS CRIAR UM NOVO USAMOS LayoutInflater 
		 */
		if (row == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			row = inflater.inflate(R.layout.single_row, parent, false);
			holder = new MyViewHolder(row);
			row.setTag(holder);
			
		} else {
			holder = (MyViewHolder) row.getTag();
		}
		
		holder.box.setTag(position);
		boolean isFound = false;
		for(int i=0; i<boxPositions.size(); i++){
			if(boxPositions.get(i) == position){
				isFound = true;
			}
		}
		holder.box.setChecked(isFound);
		holder.box.setOnCheckedChangeListener(this);	
		
		SingleRow temp = list.get(position);
		holder.title.setText(temp.title);
		holder.description.setText(temp.descripton);
		holder.image.setImageResource(temp.image);
		
		return row;
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		int position = (Integer) buttonView.getTag();
		if (isChecked) {
			boolean add = true;
			for (int i = 0; i < boxPositions.size(); i++) {
				if (boxPositions.get(i) == position) {
					//nao adicionamos
					add=false;
				}
			}
			if(add){
				boxPositions.add(position);
				Log.d("VIVZ", "++"+ position+" "+ boxPositions.toString());
			}
		} else {
			for (int i = 0; i < boxPositions.size(); i++) {
				if (boxPositions.get(i) == position) {
					boxPositions.remove(i);
				}
			}
			Log.d("VIVZ", "--"+position+" "+boxPositions.toString());
		}

	}
	
}