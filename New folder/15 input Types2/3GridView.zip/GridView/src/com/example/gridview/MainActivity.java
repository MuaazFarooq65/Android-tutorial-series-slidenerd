package com.example.gridview;

import java.util.ArrayList;

import com.example.gridview.VivzAdapter.ViewHolder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity implements OnItemClickListener{
	
	GridView myGrid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        myGrid = (GridView) findViewById(R.id.gridView1);
        VivzAdapter adapter = new VivzAdapter(this);
        myGrid.setAdapter(adapter);
        myGrid.setOnItemClickListener(this);
    }
    
    /*
     * parent = gridview
     * view = item was click
     */
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		Intent intent = new Intent(this, Mydialog.class);
		
		ViewHolder holder =  (ViewHolder) view.getTag();
		Country temp = (Country) holder.mycountry.getTag();
		
		intent.putExtra("countryImage", temp.imageId);
		intent.putExtra("countryName", temp.countryName);
		startActivity(intent);
	}
}

class Country {
	int imageId;
	String countryName;
	
	public Country(int imageId, String countryName) {
		this.imageId = imageId;
		this.countryName = countryName;
	}
}

class VivzAdapter extends BaseAdapter {
	
	ArrayList<Country> list;
	Context context;
	VivzAdapter(Context context){
		this.context = context;
		list = new ArrayList<Country>();
		
		//meter dados
		Resources res = context.getResources();
		String[] tempCountryNames =  res.getStringArray(R.array.country_name);
		int[] countryImages = { R.drawable.canada, R.drawable.china,
				R.drawable.germany, R.drawable.india, R.drawable.italy,
				R.drawable.portugal, R.drawable.russia, R.drawable.spain,
				R.drawable.uk, R.drawable.us, R.drawable.canada,
				R.drawable.china, R.drawable.germany, R.drawable.india,
				R.drawable.italy, R.drawable.portugal, R.drawable.russia,
				R.drawable.spain, R.drawable.uk, R.drawable.us,
				R.drawable.canada, R.drawable.china, R.drawable.germany,
				R.drawable.india, R.drawable.italy, R.drawable.portugal,
				R.drawable.russia, R.drawable.spain, R.drawable.uk,
				R.drawable.us };
		for (int i = 0; i < 30; i++) {
			Country tempCountry = new Country(countryImages[i], tempCountryNames[i]);
			list.add(tempCountry);
		}
	}
	
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	//175%
	class ViewHolder {
		ImageView mycountry;
		
		public ViewHolder(View v) {
			mycountry = (ImageView) v.findViewById(R.id.imageView1);
		}
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		ViewHolder holder = null;
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			row = inflater.inflate(R.layout.single_item, parent, false);
			holder = new ViewHolder(row);
			row.setTag(holder);
		} else {
			holder=(ViewHolder) row.getTag();
		}
		Country temp = list.get(position);
		holder.mycountry.setImageResource(temp.imageId);
		holder.mycountry.setTag(temp);
		return row;
	}
}