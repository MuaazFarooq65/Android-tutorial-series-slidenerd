package com.example.listviewiconslayout;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity implements OnItemClickListener {

	String[] data = { "Domingo", "Segunda", "Ter�a", "Quarta", "Quinta",
			"Sexta", "Sabado" };
	ListView l;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// referencias
		l = (ListView) findViewById(R.id.listView1);

		/*
		 * context = esta classse = this 
		 * layout que vai ser usado na list view = single_row 
		 * onde vao ser metidos os dados = textView1 
		 * dados = data
		 */
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				R.layout.single_row, R.id.textView1, data);
		l.setAdapter(adapter);
		l.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Object actual = l.getItemAtPosition(position);
		Toast.makeText(this, actual.toString() + " " + position,
				Toast.LENGTH_SHORT).show();
	}
}