package com.example.listviewholder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.listviewiconsdescription.R;

public class MainActivity extends Activity implements OnClickListener{

	String[] titles, descriptions;
	int[] images = { R.drawable.image1, R.drawable.image2, R.drawable.image3,
			R.drawable.image4, R.drawable.image5, R.drawable.image6,
			R.drawable.image7, R.drawable.image8, R.drawable.image9,
			R.drawable.image10, R.drawable.image11, R.drawable.image12,
			R.drawable.image13, R.drawable.image14, R.drawable.image15,
			R.drawable.image16, R.drawable.image17, R.drawable.image18,
			R.drawable.image19, R.drawable.image29,R.drawable.image1, R.drawable.image2, R.drawable.image3,
			R.drawable.image4, R.drawable.image5, R.drawable.image6,
			R.drawable.image7, R.drawable.image8, R.drawable.image9,
			R.drawable.image10, R.drawable.image11, R.drawable.image12,
			R.drawable.image13, R.drawable.image14, R.drawable.image15,
			R.drawable.image16, R.drawable.image17, R.drawable.image18,
			R.drawable.image19, R.drawable.image29 };
	ListView list;
	Button calc;
	EditText editResult;
	List<Integer> finalPositions = new ArrayList<Integer>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Resources res = getResources();
		titles = res.getStringArray(R.array.titles);
		descriptions = res.getStringArray(R.array.descriptions);
		list = (ListView) findViewById(R.id.listView1);
		
		calc= (Button) findViewById(R.id.button1);
		editResult = (EditText) findViewById(R.id.editText1);
		calc.setOnClickListener(this);

		VivzAdapter adapter = new VivzAdapter(this, titles, images,	descriptions);
		list.setAdapter(adapter);
		
		finalPositions=adapter.positions;
	}

	@Override
	public void onClick(View v) {
		int result=0;
		for (int i = 0; i < finalPositions.size(); i++) {
			result+=finalPositions.get(i);
		}
		editResult.setText(""+result);
	}
}

class VivzAdapter extends ArrayAdapter<String> implements OnCheckedChangeListener {
	Context context;
	int[] images;
	String[] titlesArray, descrptionArray;
	List<Integer> positions = new ArrayList<Integer>();

	VivzAdapter(Context context, String[] titles, int[] images,
			String[] description) {

		super(context, R.layout.single_row, R.id.textView1, titles);
		this.context = context;
		this.images = images;
		this.titlesArray = titles;
		this.descrptionArray = description;
	}

	class MyViewHolder {
		ImageView myImage;
		TextView myTitle;
		TextView myDescription;
		CheckBox box;
		
		MyViewHolder(View v) {
			myImage = (ImageView) v.findViewById(R.id.imageView1);
			myTitle = (TextView) v.findViewById(R.id.textView1);
			myDescription = (TextView) v.findViewById(R.id.textView2);
			box = (CheckBox) v.findViewById(R.id.checkBox1);
		}
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		MyViewHolder holder = null;
		if (row == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			
			row = inflater.inflate(R.layout.single_row, parent, false);
			holder = new MyViewHolder(row);
			row.setTag(holder);
		} else {
			holder = (MyViewHolder) row.getTag();
		}
		holder.myImage.setImageResource(images[position]);
		holder.myTitle.setText(titlesArray[position]);
		holder.myDescription.setText(descrptionArray[position]);
		holder.box.setTag(position);
		
		
		boolean isFound = false;
		for (int i = 0; i < positions.size(); i++) {
			if(positions.get(i) == position){
				isFound=true;
			}
		}

		holder.box.setChecked(isFound);		
		holder.box.setOnCheckedChangeListener(this);
		return row;
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		int position = (Integer)buttonView.getTag();
		if(isChecked){
			boolean isFound = false;
			for (int i = 0; i < positions.size(); i++) {
				if(positions.get(i) == position){
					isFound = true;
				}
			}
			if(!isFound){
				positions.add(position);
				Log.d("VIVZ", "+ "+position);
			}
		} else {
			Integer number = position;
			try {
				positions.remove(number);
				Log.d("VIVZ", "- "+number);
			} catch (Exception e) {
				Log.d("VIVZ", "----- "+number);
			}
		}
		Log.d("VIVZ", positions.toString());
	}


}
