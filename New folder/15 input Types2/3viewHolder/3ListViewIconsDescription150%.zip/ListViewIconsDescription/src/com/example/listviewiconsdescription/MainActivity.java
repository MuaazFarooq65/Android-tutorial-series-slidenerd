package com.example.listviewiconsdescription;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.os.Build;

public class MainActivity extends Activity {

	String[] titles, descriptions;
	int[] images = { R.drawable.image1, R.drawable.image2, R.drawable.image3,
			R.drawable.image4, R.drawable.image5, R.drawable.image6,
			R.drawable.image7, R.drawable.image8, R.drawable.image9,
			R.drawable.image10, R.drawable.image11, R.drawable.image12,
			R.drawable.image13, R.drawable.image14, R.drawable.image15,
			R.drawable.image16, R.drawable.image17, R.drawable.image18,
			R.drawable.image19, R.drawable.image29 };
	ListView list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Resources res = getResources();
		titles = res.getStringArray(R.array.titles);
		descriptions = res.getStringArray(R.array.descriptions);
		list = (ListView) findViewById(R.id.listView1);
		
		VivzAdapter adapter = new VivzAdapter(this, titles, images, descriptions);
		list.setAdapter(adapter);
		
	}
}

class VivzAdapter extends ArrayAdapter<String> {
	Context context;
	int[] images;
	String[] titlesArray, descrptionArray;

	VivzAdapter(Context context, String[] titles, int[] images, String[] description) {
		/*
		 * this
		 * layout que vamos usar para fazer 1 linha=single_row
		 * quando criamos construtor � REQUERIDO que criamos link entre TextView e String Array
		 * Como temos 2 escolhemos 1 qq, neste caso escolhemos textView1+titles
		 */
		super(context, R.layout.single_row, R.id.textView1, titles);
		this.context = context;
		this.images=images;
		this.titlesArray=titles;
		this.descrptionArray=description;
	}
	
//	/*
//	 * metodo chamado por default para obter view
//	 * SEM OPTIMIZACAO
//	 */
//	@Override
//	public View getView(int position, View convertView, ViewGroup parent) {
//		// temos coverter single_row xml para objectos java para podermos
//		// accessar os seus dados como with...
//		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//
//		View row = inflater.inflate(R.layout.single_row, parent, false);
//		/*
//		 * row � apontador para RelativeLAYOUT DE SINGLE ROW assim podemos
//		 * encontrar imageView, e dois textViews
//		 */
//		
//		ImageView image = (ImageView) row.findViewById(R.id.imageView1);
//		TextView titles = (TextView) row.findViewById(R.id.textView1);
//		TextView description = (TextView) row.findViewById(R.id.textView2);
//
//		image.setImageResource(images[position]);
//		titles.setText(titlesArray[position]);
//		description.setText(descrptionArray[position]);
//		
//		
//		return row;
//	}
	
	/*
	 * metodo chamado por default para obter view
	 * OPTIMIZACAO 150%
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		/*
		 * inicialmente convertView � null
		 * depois tens parametros da antiga view
		 */
		View row = convertView;
		if (row==null) {
			// temos coverter single_row xml para objectos java para podermos
			// accessar os seus dados como with...
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			row = inflater.inflate(R.layout.single_row, parent, false);
			/*
			 * row � apontador para RelativeLAYOUT DE SINGLE ROW assim podemos
			 * encontrar imageView, e dois textViews
			 */
		} 
		
		ImageView image = (ImageView) row.findViewById(R.id.imageView1);
		TextView titles = (TextView) row.findViewById(R.id.textView1);
		TextView description = (TextView) row.findViewById(R.id.textView2);

		image.setImageResource(images[position]);
		titles.setText(titlesArray[position]);
		description.setText(descrptionArray[position]);
		
		
		return row;
	}
}
