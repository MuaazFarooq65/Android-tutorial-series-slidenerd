package com.example.listviewholder;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.listviewiconsdescription.R;

public class MainActivity extends Activity implements OnItemClickListener{

	String[] titles, descriptions;
	int[] images = { R.drawable.image1, R.drawable.image2, R.drawable.image3,
			R.drawable.image4, R.drawable.image5, R.drawable.image6,
			R.drawable.image7, R.drawable.image8, R.drawable.image9,
			R.drawable.image10, R.drawable.image11, R.drawable.image12,
			R.drawable.image13, R.drawable.image14, R.drawable.image15,
			R.drawable.image16, R.drawable.image17, R.drawable.image18,
			R.drawable.image19, R.drawable.image29 };
	ListView list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Resources res = getResources();
		titles = res.getStringArray(R.array.titles);
		descriptions = res.getStringArray(R.array.descriptions);
		list = (ListView) findViewById(R.id.listView1);

		VivzAdapter adapter = new VivzAdapter(this, titles, images,
				descriptions);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Toast.makeText(this, titles[position]+" "+descriptions[position], Toast.LENGTH_SHORT).show();
	}
}

class VivzAdapter extends ArrayAdapter<String> {
	Context context;
	int[] images;
	String[] titlesArray, descrptionArray;

	VivzAdapter(Context context, String[] titles, int[] images,
			String[] description) {

		super(context, R.layout.single_row, R.id.textView1, titles);
		this.context = context;
		this.images = images;
		this.titlesArray = titles;
		this.descrptionArray = description;
	}

	class MyViewHolder {
		ImageView myImage;
		TextView myTitle;
		TextView myDescription;

		MyViewHolder(View v) {
			myImage = (ImageView) v.findViewById(R.id.imageView1);
			myTitle = (TextView) v.findViewById(R.id.textView1);
			myDescription = (TextView) v.findViewById(R.id.textView2);

		}
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// quando criamos estes 2 objectos, inicialmente sao ambos null
		View row = convertView;
		MyViewHolder holder = null;
		if (row == null) {
			// 1.�time
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			
			//row contem RelativeLayout(root) em single_row.xml
			row = inflater.inflate(R.layout.single_row, parent, false);
			holder = new MyViewHolder(row);
			row.setTag(holder);
			Log.d("VIVZ", "Creating a new Row");
		} else {
			//reciclamos aqui, qeremos usar antigo objecto holder
			holder = (MyViewHolder) row.getTag();
			Log.d("VIVZ", "Recycling stuff");
		}
		

		holder.myImage.setImageResource(images[position]);
		holder.myTitle.setText(titlesArray[position]);
		holder.myDescription.setText(descrptionArray[position]);

		return row;
	}
}
