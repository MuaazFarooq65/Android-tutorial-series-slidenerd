package slidenerd.vivz;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{
	
	CheckBox sugar, cinnamon;	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        sugar = (CheckBox) findViewById(R.id.checkBox1);
        cinnamon = (CheckBox) findViewById(R.id.checkBox2);
        
        sugar.setOnClickListener(this);
        cinnamon.setOnClickListener(this);
        
    }
	@Override
	public void onClick(View view) {
		/*
		 * temos saber qual a checkbox clicada
		 * problemas com cast
		 */
		CheckBox check = (CheckBox)view;
		if (check.getId() == sugar.getId()) {
			if (sugar.isChecked()) {
				Toast.makeText(this, "sugar true", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "sugar false", Toast.LENGTH_SHORT).show();
			}
		} else if(check.getId() == cinnamon.getId()){
			if (cinnamon.isChecked()) {
				Toast.makeText(this, "cinnamon true", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "cinnamon false", Toast.LENGTH_SHORT).show();
			}
		}
	}
}
