package slidenerd.vivz;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity implements TextWatcher {

	EditText validate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		validate = (EditText) findViewById(R.id.validate);
		validate.addTextChangedListener(this);

	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		Toast.makeText(this, "before changed", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		Toast.makeText(this, "on the text", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void afterTextChanged(Editable editable) {
		// Toast.makeText(this, "after changed", Toast.LENGTH_SHORT).show();
		try {
			int no = Integer.parseInt(editable.toString());
			if (no > 100) {
				// posicoes
				editable.replace(0, editable.length(), "100");
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}