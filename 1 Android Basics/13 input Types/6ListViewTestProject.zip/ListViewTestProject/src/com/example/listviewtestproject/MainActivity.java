package com.example.listviewtestproject;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity implements OnItemClickListener {

	String[] dias = { "segunda", "ter�a", "quarta", "quinta", "sexta",
			"sabado", "domingo" };
	ListView list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		list = (ListView) findViewById(R.id.listView1);

		/*
		 * usamos layout ja definido - simple_list_item_1 context 
		 * mostramos como
		 * qeremos q layout seja definido 
		 * dados
		 */
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, dias);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		TextView temp = (TextView) view;
		Toast.makeText(this,
				temp.getText().toString() + " posicao: " + position,
				Toast.LENGTH_SHORT).show();

	}
}