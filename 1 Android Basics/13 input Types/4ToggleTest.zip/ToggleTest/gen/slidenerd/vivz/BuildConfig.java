/** Automatically generated file. DO NOT MODIFY */
package slidenerd.vivz;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}