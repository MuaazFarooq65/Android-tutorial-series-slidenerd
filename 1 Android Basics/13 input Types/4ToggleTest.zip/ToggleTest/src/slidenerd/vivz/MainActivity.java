package slidenerd.vivz;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.ToggleButton;

public class MainActivity extends Activity implements OnCheckedChangeListener {

	RelativeLayout layout;
	ToggleButton button1, button2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		button1 = (ToggleButton) findViewById(R.id.toggleButton1);
		button2 = (ToggleButton) findViewById(R.id.toggleButton2);
		layout = (RelativeLayout) findViewById(R.id.layout);
		button1.setOnCheckedChangeListener(this);
		button2.setOnCheckedChangeListener(this);
	}

	/*
	 * buttonView - nome botao isChecked - true
	 */
	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (buttonView.getId() == button1.getId()) {
			if (isChecked) {
				layout.setBackgroundColor(Color.BLACK);
			} else {
				layout.setBackgroundColor(Color.WHITE);
			}
		} else if (buttonView.getId() == button2.getId()) {
			if (isChecked) {
				layout.setBackgroundColor(Color.RED);
			} else {
				layout.setBackgroundColor(Color.GREEN);
			}
		}

	}
}