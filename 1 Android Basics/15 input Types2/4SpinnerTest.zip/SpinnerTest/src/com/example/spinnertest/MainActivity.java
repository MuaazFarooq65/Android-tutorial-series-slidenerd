package com.example.spinnertest;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends Activity implements OnItemSelectedListener{
	
	Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        spinner =  (Spinner) findViewById(R.id.spinner1);
        
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.dias, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        
    }
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		TextView myText= (TextView) view;
		Toast.makeText(this, "Selecionou "+myText.getText(), Toast.LENGTH_SHORT).show();
	}
	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		
	}
}