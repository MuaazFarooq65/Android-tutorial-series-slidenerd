package slidenerd.vivz;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.os.Build;

public class MainActivity extends Activity {

	Button button;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		button = (Button) findViewById(R.id.button1);
		VivzHandler v = new VivzHandler();
		button.setOnClickListener(v);
	}

	class VivzHandler implements OnClickListener {
		@Override
		public void onClick(View v) {
			Log.d("VIVZ", "button was clicked");
		}
	}
}
