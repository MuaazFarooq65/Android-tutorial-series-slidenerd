package slidenerd.vivz;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	Button button;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		button = (Button) findViewById(R.id.button1);
		//button.setOnClickListener(o);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.d("VIVZ", "button was clicked");
			}
		});
	}

	/*
	 * anounymous inner class
	 */
	OnClickListener o = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			Log.d("VIVZ", "button was clicked");
		}
	};
}
