/** Automatically generated file. DO NOT MODIFY */
package com.example.fragmentbackstack;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}