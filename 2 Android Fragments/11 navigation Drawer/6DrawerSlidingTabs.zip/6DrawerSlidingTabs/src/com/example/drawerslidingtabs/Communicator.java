package com.example.drawerslidingtabs;

import android.support.v4.view.ViewPager;

public interface Communicator {

	public void sendViewPager(ViewPager viewpager);
}
