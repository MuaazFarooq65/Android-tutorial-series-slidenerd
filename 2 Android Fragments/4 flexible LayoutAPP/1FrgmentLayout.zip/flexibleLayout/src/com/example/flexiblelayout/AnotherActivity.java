package com.example.flexiblelayout;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.app.Activity;
import android.app.FragmentManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;

public class AnotherActivity extends Activity {

	boolean landscape=false;
	int index;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_another);

		Intent intent = getIntent();
		index = intent.getIntExtra("index", 0);
		FragmentB f2 = (FragmentB) getFragmentManager().findFragmentById(
				R.id.fragment2);
		if (f2 != null) {
			f2.changeData(index);
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
			landscape=true;
			Intent intent = new Intent(this, MainActivity.class);
			intent.putExtra("AnotherActivityIndex", index);
			startActivity(intent);
		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
			landscape=false;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(this, MainActivity.class);
			startActivity(intent);
			AnotherActivity.this.finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
