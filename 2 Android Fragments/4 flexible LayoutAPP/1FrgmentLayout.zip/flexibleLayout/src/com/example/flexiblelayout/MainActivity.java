package com.example.flexiblelayout;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;

public class MainActivity extends Activity implements FragmentA.Communicator {

	FragmentManager manager;
	int AnotherActivityIndex;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Intent intent = getIntent();
		AnotherActivityIndex = intent.getIntExtra("AnotherActivityIndex", -1);
		Log.d("VIVZ", ""+AnotherActivityIndex);
		
		manager = getFragmentManager();
		FragmentA f1 = (FragmentA) manager.findFragmentById(R.id.fragment1);		
		f1.setCommunicator(this);
	}

	@Override
	public void respond(int index) {
		FragmentB f2 = (FragmentB) manager.findFragmentById(R.id.fragment2);
		if (f2 != null && f2.isVisible()) {
			f2.changeData(index);
		} else {
			Intent intent = new Intent(this, AnotherActivity.class);
			intent.putExtra("index", index);
			startActivity(intent);
		}

	}
}