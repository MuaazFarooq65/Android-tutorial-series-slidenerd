package com.example.modularui;

public interface Communicator {
	
	public void respond(int i);
}
