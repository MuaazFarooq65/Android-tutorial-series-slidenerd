package com.example.modularui;

import android.app.Fragment;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FragmentB extends Fragment {
	
	TextView text;
	int index;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_b, container, false);
		if (savedInstanceState==null) {
			//nada
		} else {
			index = savedInstanceState.getInt("index");
			text = (TextView) view.findViewById(R.id.textView1);
			changeData(index);
		}
		return view;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		text = (TextView) getActivity().findViewById(R.id.textView1);
	}
	
	public void changeData(int i) {
		index = i;
		Resources res = getResources();
		String[] descriptions = res.getStringArray(R.array.descriptons);
		text.setText(descriptions[i]);
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt("index", index);
	}
}
