/** Automatically generated file. DO NOT MODIFY */
package com.example.inter_fragment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}