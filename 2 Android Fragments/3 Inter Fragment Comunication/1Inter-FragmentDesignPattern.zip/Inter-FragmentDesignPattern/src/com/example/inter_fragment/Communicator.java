package com.example.inter_fragment;

public interface Communicator {
	public void respond(String data);
}
